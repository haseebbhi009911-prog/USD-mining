import React, { useState, useEffect } from 'react';
import { Pickaxe, Zap } from 'lucide-react';

interface ClickAreaProps {
  onTap: () => void;
  clickPower: number;
}

export const ClickArea: React.FC<ClickAreaProps> = ({ onTap, clickPower }) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number; val: number }[]>([]);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Visual feedback logic
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 100);

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const newRipple = {
      id: Date.now(),
      x,
      y,
      val: clickPower
    };

    setRipples(prev => [...prev, newRipple]);
    
    // Trigger actual game logic
    onTap();
  };

  // Clean up ripples
  useEffect(() => {
    if (ripples.length > 0) {
      const timer = setTimeout(() => {
        setRipples(prev => prev.slice(1));
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [ripples]);

  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[400px]">
      <div className="relative w-64 h-64 md:w-80 md:h-80">
        {/* Glow Effect */}
        <div className="absolute inset-0 bg-emerald-500/20 blur-[60px] rounded-full animate-pulse" />
        
        {/* Main Button */}
        <button
          onClick={handleClick}
          className={`
            relative w-full h-full rounded-full 
            bg-gradient-to-b from-slate-800 to-slate-900 
            border-4 border-emerald-500/30 
            shadow-[0_0_40px_rgba(16,185,129,0.2)]
            hover:border-emerald-500/60 hover:shadow-[0_0_60px_rgba(16,185,129,0.4)]
            active:scale-95 transition-all duration-100 ease-out
            flex items-center justify-center
            group overflow-hidden
          `}
        >
          {/* Inner details */}
          <div className="absolute inset-2 rounded-full border border-slate-700/50 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-slate-950" />
          
          <div className={`transform transition-transform duration-100 ${isAnimating ? 'scale-90 rotate-[-10deg]' : 'scale-100'}`}>
            <Pickaxe size={80} className="text-emerald-400 drop-shadow-lg" />
          </div>

          <div className="absolute bottom-12 text-emerald-500/60 font-mono text-sm tracking-widest uppercase">
            Tap to Mine
          </div>

          {/* Floating Numbers */}
          {ripples.map((r) => (
             <div
               key={r.id}
               className="absolute pointer-events-none font-bold text-2xl text-white animate-float-up"
               style={{ 
                 left: r.x, 
                 top: r.y,
                 textShadow: '0 2px 10px rgba(0,0,0,0.5)'
               }}
             >
               +${r.val.toLocaleString()}
             </div>
          ))}
        </button>
      </div>

      <div className="mt-12 text-center space-y-2">
        <h2 className="text-slate-400 text-sm uppercase tracking-widest">Mining Efficiency</h2>
        <div className="flex items-center justify-center gap-2 text-2xl font-bold text-white font-mono">
          <Zap className="text-yellow-400 fill-yellow-400" size={24} />
          ${clickPower.toLocaleString()} <span className="text-sm text-slate-500 font-normal self-end mb-1">/ tap</span>
        </div>
      </div>
    </div>
  );
};
