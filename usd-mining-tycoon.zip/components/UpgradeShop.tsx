import React from 'react';
import { Upgrade, UpgradeType } from '../types';
import { MousePointer2, Keyboard, HandMetal, Globe, Cpu, Server, Atom, BrainCircuit, LucideIcon } from 'lucide-react';

interface UpgradeShopProps {
  upgrades: Upgrade[];
  balance: number;
  onBuy: (upgradeId: string) => void;
}

const iconMap: Record<string, LucideIcon> = {
  MousePointer2,
  Keyboard,
  HandMetal,
  Globe,
  Cpu,
  Server,
  Atom,
  BrainCircuit
};

interface UpgradeCardProps {
  item: Upgrade;
  balance: number;
  onBuy: (id: string) => void;
}

const UpgradeCard: React.FC<UpgradeCardProps> = ({ item, balance, onBuy }) => {
  const cost = Math.floor(item.baseCost * Math.pow(item.costMultiplier, item.level));
  const canAfford = balance >= cost;
  const Icon = iconMap[item.icon] || Cpu;

  return (
    <button
      onClick={() => onBuy(item.id)}
      disabled={!canAfford}
      className={`
        flex items-center justify-between w-full p-4 mb-3 rounded-xl border transition-all duration-200 group
        ${canAfford 
          ? 'bg-slate-800 border-slate-700 hover:border-emerald-500/50 hover:bg-slate-750 hover:shadow-lg hover:shadow-emerald-900/10 cursor-pointer active:scale-[0.98]' 
          : 'bg-slate-900/50 border-slate-800 opacity-60 cursor-not-allowed'}
      `}
    >
      <div className="flex items-center gap-4">
        <div className={`
          p-3 rounded-lg 
          ${canAfford ? 'bg-emerald-500/10 text-emerald-400 group-hover:text-emerald-300' : 'bg-slate-800 text-slate-500'}
        `}>
          <Icon size={24} />
        </div>
        <div className="text-left">
          <h4 className="font-bold text-slate-200">{item.name} <span className="text-xs font-normal text-slate-500 ml-1">Lvl {item.level}</span></h4>
          <p className="text-xs text-slate-400">{item.description}</p>
          <p className="text-xs font-mono text-emerald-500/80 mt-1">
            +{item.basePower} {item.type === UpgradeType.CLICK ? '$/tap' : '$/sec'}
          </p>
        </div>
      </div>
      
      <div className="text-right">
        <div className={`font-mono font-bold ${canAfford ? 'text-white' : 'text-slate-500'}`}>
          ${cost.toLocaleString()}
        </div>
        <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mt-1">
          Buy
        </div>
      </div>
    </button>
  );
};

export const UpgradeShop: React.FC<UpgradeShopProps> = ({ upgrades, balance, onBuy }) => {
  const clickUpgrades = upgrades.filter(u => u.type === UpgradeType.CLICK);
  const autoUpgrades = upgrades.filter(u => u.type === UpgradeType.AUTO);

  return (
    <div className="h-full overflow-y-auto pr-2 custom-scrollbar">
      <div className="mb-8">
        <h3 className="text-lg font-bold text-slate-400 mb-4 flex items-center gap-2 uppercase tracking-widest text-xs">
          <MousePointer2 size={14} /> Manual Upgrades
        </h3>
        {clickUpgrades.map(u => <UpgradeCard key={u.id} item={u} balance={balance} onBuy={onBuy} />)}
      </div>

      <div>
        <h3 className="text-lg font-bold text-slate-400 mb-4 flex items-center gap-2 uppercase tracking-widest text-xs">
          <Cpu size={14} /> Automated Infrastructure
        </h3>
        {autoUpgrades.map(u => <UpgradeCard key={u.id} item={u} balance={balance} onBuy={onBuy} />)}
      </div>
    </div>
  );
};