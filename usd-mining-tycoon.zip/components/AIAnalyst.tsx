import React, { useState } from 'react';
import { Bot, Sparkles, Loader2 } from 'lucide-react';
import { generateMarketAnalysis } from '../services/geminiService';

interface AIAnalystProps {
  onBonus: (multiplier: number) => void;
}

export const AIAnalyst: React.FC<AIAnalystProps> = ({ onBonus }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastAnalysis, setLastAnalysis] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);

  const handleAnalyze = async () => {
    if (isAnalyzing || cooldown > 0) return;

    setIsAnalyzing(true);
    setLastAnalysis(null);

    // AI Call
    const result = await generateMarketAnalysis();
    
    setLastAnalysis(result.text);
    onBonus(result.bonusMultiplier);
    setIsAnalyzing(false);

    // Set cooldown (e.g., 30 seconds)
    setCooldown(30);
    const interval = setInterval(() => {
      setCooldown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50 backdrop-blur-sm">
      <div className="flex items-start gap-4">
        <div className="p-3 bg-indigo-500/20 rounded-lg text-indigo-400 shrink-0">
          <Bot size={28} />
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-bold text-slate-200 flex items-center gap-2">
              Gemini AI Analyst
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30">v2.5</span>
            </h3>
            {cooldown > 0 && (
              <span className="text-xs font-mono text-slate-500">{cooldown}s cooldown</span>
            )}
          </div>
          
          <div className="min-h-[60px] mb-3 text-sm text-slate-400 bg-slate-900/50 rounded-lg p-3 border border-slate-800 font-mono leading-relaxed">
            {isAnalyzing ? (
              <div className="flex items-center gap-2 text-indigo-400 animate-pulse">
                <Loader2 size={14} className="animate-spin" />
                <span>Processing blockchain heuristics...</span>
              </div>
            ) : lastAnalysis ? (
              <span className="text-emerald-400">"{lastAnalysis}"</span>
            ) : (
              "System idle. Request analysis for a mining efficiency boost."
            )}
          </div>

          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing || cooldown > 0}
            className={`
              w-full py-2 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 transition-all
              ${isAnalyzing || cooldown > 0 
                ? 'bg-slate-700 text-slate-500 cursor-not-allowed' 
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-900/20 active:scale-[0.98]'}
            `}
          >
            {isAnalyzing ? (
              "Analyzing..."
            ) : (
              <>
                <Sparkles size={16} /> Request Market Insight
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
