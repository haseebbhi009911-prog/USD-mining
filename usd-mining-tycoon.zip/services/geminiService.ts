import { GoogleGenAI } from "@google/genai";
import { AIAnalysisResult } from "../types";

// Initialize the client
// The API key is assumed to be available in process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateMarketAnalysis = async (): Promise<AIAnalysisResult> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      You are a futuristic crypto-financial AI advisor in a game. 
      Generate a very short, witty, one-sentence "market analysis" or "hack result". 
      It should sound high-tech, cyberpunk, or financial.
      Examples:
      - "Detected arbitrage opportunity in sector 7G."
      - "Mainframe firewall bypassed. Siphoning residual credits."
      - "Global hashrate stabilized. Efficiency up 15%."
      - "Bear market inverted via quantum tunneling."
      
      Keep it under 15 words.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    const text = response.text?.trim() || "System online. Analysis pending.";
    
    // Randomize a bonus multiplier between 1.5x and 5.0x for the user interaction
    const bonusMultiplier = 1.5 + Math.random() * 3.5;

    return {
      text,
      bonusMultiplier
    };

  } catch (error) {
    console.error("AI Generation Error:", error);
    return {
      text: "Connection unstable. Backup protocols active.",
      bonusMultiplier: 1.2
    };
  }
};
