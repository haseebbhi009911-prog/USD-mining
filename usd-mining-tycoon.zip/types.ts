export enum UpgradeType {
  CLICK = 'CLICK',
  AUTO = 'AUTO'
}

export interface Upgrade {
  id: string;
  name: string;
  description: string;
  baseCost: number;
  basePower: number; // Amount added to click or auto rate
  type: UpgradeType;
  level: number;
  costMultiplier: number;
  icon: string;
}

export interface GameState {
  balance: number;
  lifetimeEarnings: number;
  clickPower: number;
  autoMineRate: number; // USD per second
  upgrades: Upgrade[];
  startTime: number;
}

export interface AIAnalysisResult {
  text: string;
  bonusMultiplier: number;
}
