import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Coins, History, Save, RotateCcw, TrendingUp } from 'lucide-react';
import { GameState, Upgrade, UpgradeType } from './types';
import { INITIAL_STATE } from './constants';
import { ClickArea } from './components/ClickArea';
import { UpgradeShop } from './components/UpgradeShop';
import { AIAnalyst } from './components/AIAnalyst';

// Key for localStorage
const SAVE_KEY = 'usd_miner_save_v1';

const App = () => {
  // State initialization with lazy loading from localStorage
  const [gameState, setGameState] = useState<GameState>(() => {
    const saved = localStorage.getItem(SAVE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Merge with initial state to ensure new fields are present if schema changes
        return { ...INITIAL_STATE, ...parsed };
      } catch (e) {
        console.error("Failed to load save", e);
        return INITIAL_STATE;
      }
    }
    return INITIAL_STATE;
  });

  // Derived state for formatted balance
  const formattedBalance = gameState.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const formattedRate = gameState.autoMineRate.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 1 });

  // Passive Income Loop - runs every 100ms for smoothness
  useEffect(() => {
    if (gameState.autoMineRate === 0) return;

    const interval = setInterval(() => {
      setGameState(prev => ({
        ...prev,
        balance: prev.balance + (prev.autoMineRate / 10),
        lifetimeEarnings: prev.lifetimeEarnings + (prev.autoMineRate / 10)
      }));
    }, 100);

    return () => clearInterval(interval);
  }, [gameState.autoMineRate]);

  // Auto-save every 30 seconds
  useEffect(() => {
    const saveInterval = setInterval(() => {
      localStorage.setItem(SAVE_KEY, JSON.stringify(gameState));
    }, 30000);
    return () => clearInterval(saveInterval);
  }, [gameState]);

  // Handle manual tap
  const handleTap = useCallback(() => {
    setGameState(prev => ({
      ...prev,
      balance: prev.balance + prev.clickPower,
      lifetimeEarnings: prev.lifetimeEarnings + prev.clickPower
    }));
  }, []);

  // Handle upgrade purchase
  const handleBuyUpgrade = (upgradeId: string) => {
    setGameState(prev => {
      const upgradeIndex = prev.upgrades.findIndex(u => u.id === upgradeId);
      if (upgradeIndex === -1) return prev;

      const upgrade = prev.upgrades[upgradeIndex];
      const cost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, upgrade.level));

      if (prev.balance < cost) return prev; // Should be handled by UI, but double check

      // Create new upgrades array
      const newUpgrades = [...prev.upgrades];
      newUpgrades[upgradeIndex] = {
        ...upgrade,
        level: upgrade.level + 1
      };

      // Calculate new powers
      let newClickPower = prev.clickPower;
      let newAutoRate = prev.autoMineRate;

      if (upgrade.type === UpgradeType.CLICK) {
        newClickPower += upgrade.basePower;
      } else {
        newAutoRate += upgrade.basePower;
      }

      return {
        ...prev,
        balance: prev.balance - cost,
        upgrades: newUpgrades,
        clickPower: newClickPower,
        autoMineRate: newAutoRate
      };
    });
  };

  // Handle AI Bonus
  const handleAIBonus = (multiplier: number) => {
    // Grant a lump sum based on current production (or a flat amount if production is low)
    // Formula: (Auto Rate * 60s) * Multiplier OR (Click Power * 50) * Multiplier
    const baseValue = Math.max(gameState.autoMineRate * 60, gameState.clickPower * 50);
    const bonusAmount = baseValue * multiplier;
    
    setGameState(prev => ({
      ...prev,
      balance: prev.balance + bonusAmount,
      lifetimeEarnings: prev.lifetimeEarnings + bonusAmount
    }));
  };

  // Manual Save/Reset
  const manualSave = () => {
    localStorage.setItem(SAVE_KEY, JSON.stringify(gameState));
    alert("Game Saved!");
  };

  const hardReset = () => {
    if(confirm("Are you sure you want to reset all progress? This cannot be undone.")) {
      localStorage.removeItem(SAVE_KEY);
      setGameState(INITIAL_STATE);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row overflow-hidden">
      {/* LEFT PANEL: Mining & Stats */}
      <div className="flex-1 flex flex-col relative z-10 p-6 md:p-8">
        
        {/* Header */}
        <header className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-500">
              USD Mining Tycoon
            </h1>
            <p className="text-slate-500 text-sm mt-1">Scale your digital empire.</p>
          </div>
          <div className="flex gap-2">
             <button onClick={manualSave} className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors" title="Save Game">
                <Save size={18} />
             </button>
             <button onClick={hardReset} className="p-2 text-slate-400 hover:text-red-400 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors" title="Reset Progress">
                <RotateCcw size={18} />
             </button>
          </div>
        </header>

        {/* Balance Display */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 mb-8 shadow-2xl backdrop-blur-md">
          <div className="text-slate-400 text-sm font-semibold uppercase tracking-widest mb-1">Current Balance</div>
          <div className="text-5xl md:text-6xl font-mono font-bold text-white tracking-tighter flex items-baseline gap-2">
            <span className="text-emerald-500">$</span>
            {formattedBalance}
          </div>
          <div className="mt-4 flex items-center gap-2 text-emerald-400 bg-emerald-500/10 w-fit px-3 py-1 rounded-full text-sm font-medium border border-emerald-500/20">
            <TrendingUp size={14} />
            +${formattedRate}/sec
          </div>
        </div>

        {/* Click Area (Flex Grow to fill space) */}
        <div className="flex-1 relative">
          <ClickArea onTap={handleTap} clickPower={gameState.clickPower} />
        </div>

        {/* AI Section (Bottom of Left Panel) */}
        <div className="mt-8">
          <AIAnalyst onBonus={handleAIBonus} />
        </div>
      </div>

      {/* RIGHT PANEL: Upgrades */}
      <div className="md:w-[450px] bg-slate-900 border-l border-slate-800 flex flex-col z-20 shadow-2xl">
        <div className="p-6 border-b border-slate-800 bg-slate-900/95 backdrop-blur z-20">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Coins className="text-amber-400" /> Marketplace
          </h2>
          <p className="text-slate-500 text-xs mt-1">Purchase hardware to increase yield.</p>
        </div>
        
        <div className="flex-1 overflow-hidden p-4 bg-slate-950/50">
          <UpgradeShop 
            upgrades={gameState.upgrades} 
            balance={gameState.balance} 
            onBuy={handleBuyUpgrade} 
          />
        </div>

        {/* Mini Footer Stats */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 text-xs text-slate-500 flex justify-between items-center">
           <div className="flex items-center gap-2">
             <History size={12} /> 
             Lifetime Earned: <span className="text-slate-300 font-mono">${Math.floor(gameState.lifetimeEarnings).toLocaleString()}</span>
           </div>
           <div>v1.0.0</div>
        </div>
      </div>

      {/* Background Decorative Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 opacity-20">
         <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/30 rounded-full blur-[120px]" />
         <div className="absolute bottom-[-10%] right-[10%] w-[30%] h-[30%] bg-blue-600/20 rounded-full blur-[100px]" />
      </div>

      <style>{`
        @keyframes float-up {
          0% { transform: translateY(0) scale(1); opacity: 1; }
          100% { transform: translateY(-100px) scale(1.5); opacity: 0; }
        }
        .animate-float-up {
          animation: float-up 0.8s ease-out forwards;
        }
        /* Custom scrollbar for upgrade list */
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(30, 41, 59, 0.5);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(71, 85, 105, 0.8);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(100, 116, 139, 1);
        }
      `}</style>
    </div>
  );
};

export default App;
