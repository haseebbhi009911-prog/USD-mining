import { Upgrade, UpgradeType } from './types';

export const INITIAL_UPGRADES: Upgrade[] = [
  // Click Upgrades
  {
    id: 'c1',
    name: 'Better Mouse',
    description: 'Improves tapping efficiency.',
    baseCost: 15,
    basePower: 1,
    type: UpgradeType.CLICK,
    level: 0,
    costMultiplier: 1.5,
    icon: 'MousePointer2'
  },
  {
    id: 'c2',
    name: 'Mechanical Keyboard',
    description: 'Tactile feedback increases productivity.',
    baseCost: 100,
    basePower: 5,
    type: UpgradeType.CLICK,
    level: 0,
    costMultiplier: 1.6,
    icon: 'Keyboard'
  },
  {
    id: 'c3',
    name: 'Overclocked Fingers',
    description: 'Cybernetic enhancements for your hands.',
    baseCost: 500,
    basePower: 25,
    type: UpgradeType.CLICK,
    level: 0,
    costMultiplier: 1.7,
    icon: 'HandMetal'
  },
  
  // Auto Upgrades
  {
    id: 'a1',
    name: 'Browser Miner',
    description: 'Runs a background script to mine slowly.',
    baseCost: 25,
    basePower: 1,
    type: UpgradeType.AUTO,
    level: 0,
    costMultiplier: 1.2,
    icon: 'Globe'
  },
  {
    id: 'a2',
    name: 'GPU Rig',
    description: 'A dedicated graphics card for mining.',
    baseCost: 250,
    basePower: 8,
    type: UpgradeType.AUTO,
    level: 0,
    costMultiplier: 1.3,
    icon: 'Cpu'
  },
  {
    id: 'a3',
    name: 'Server Rack',
    description: 'Industrial grade mining server.',
    baseCost: 1500,
    basePower: 40,
    type: UpgradeType.AUTO,
    level: 0,
    costMultiplier: 1.4,
    icon: 'Server'
  },
  {
    id: 'a4',
    name: 'Quantum Core',
    description: 'Experimental physics for massive gains.',
    baseCost: 10000,
    basePower: 200,
    type: UpgradeType.AUTO,
    level: 0,
    costMultiplier: 1.5,
    icon: 'Atom'
  },
  {
    id: 'a5',
    name: 'AI Neural Net',
    description: 'Self-improving mining algorithms.',
    baseCost: 50000,
    basePower: 1200,
    type: UpgradeType.AUTO,
    level: 0,
    costMultiplier: 1.6,
    icon: 'BrainCircuit'
  }
];

export const INITIAL_STATE: any = {
  balance: 0,
  lifetimeEarnings: 0,
  clickPower: 1,
  autoMineRate: 0,
  upgrades: INITIAL_UPGRADES,
  startTime: Date.now(),
};
